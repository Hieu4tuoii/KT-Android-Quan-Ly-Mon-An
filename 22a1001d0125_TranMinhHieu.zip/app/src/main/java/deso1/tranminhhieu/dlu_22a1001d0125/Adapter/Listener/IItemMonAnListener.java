package deso1.tranminhhieu.dlu_22a1001d0125.Adapter.Listener;

import deso1.tranminhhieu.dlu_22a1001d0125.Model.MonAn;

public interface IItemMonAnListener {
    void onClickUpdateButton(MonAn monAn);
}
